## ---- echo = FALSE, message = FALSE--------------------------------------
knitr::opts_chunk$set(collapse = T, comment = "#>")
library(binomial)

## ------------------------------------------------------------------------
#examples include:
#bin_choose(n = 5, k = 2)
#bin_choose(5,0)
#bin_choose(5, 1:3)

bin_choose(n = 5, k = 2)
bin_choose(5,0)
bin_choose(5, 1:3)

## ------------------------------------------------------------------------
#examples include:
#bin_distribution(trials = 5, prob = 0.5)

bin_distribution(trials = 5, prob = 0.5)

## ------------------------------------------------------------------------
#You can also plot the above probability distribution
dis1 <- bin_distribution(trials = 5, prob = 0.5)
plot(dis1)

## ------------------------------------------------------------------------
#examples include:
#bin_cumulative(trials = 5, prob = 0.5)

bin_cumulative(trials = 5, prob = 0.5)

## ------------------------------------------------------------------------
#You can also plot the above cumulative distribution
dis2 <- bin_cumulative(trials = 5, prob = 0.5)
plot(dis2)

## ------------------------------------------------------------------------
#examples include:
#bin_probability(success = 2, trials = 5, prob = 0.5)
#bin_probability(success = 0:2, trials = 5, prob = 0.5)
#bin_probability(success = 55, trials = 100, prob = 0.45)

bin_probability(success = 2, trials = 5, prob = 0.5)
bin_probability(success = 0:2, trials = 5, prob = 0.5)
bin_probability(success = 55, trials = 100, prob = 0.45)

## ------------------------------------------------------------------------
#examples
#bin_variable(3, 0.5)
#bin <- bin_variable(3, 0.5)
#summary.binvar(bin)

bin <- bin_variable(3, 0.5)
bin
summary(bin)



## ------------------------------------------------------------------------
#examples include:
#bin_mean(trials = 10, prob = 0.3)
#bin_variance(trials = 10, prob = 0.3)
#bin_mode(trials = 10, prob = 0.3)
#bin_skewness(trials = 10, prob = 0.3)
#bin_kurtosis(trials = 10, prob = 0.3)

bin_mean(trials = 10, prob = 0.3)
bin_variance(trials = 10, prob = 0.3)
bin_mode(trials = 10, prob = 0.3)
bin_skewness(trials = 10, prob = 0.3)
bin_kurtosis(trials = 10, prob = 0.3)


